# NQ VWAP Trend Trading v1.0

Prepared September 10, 2026. Historical research adaptation for MultiCharts
PowerLanguage. Sources read: all 26 pages of uploaded ssrn-4631351.pdf,
including extracted tables, author biographies and references; Table 4 was
also visually checked on page 18. Strategy/risk
information below is from that PDF, not an independent replication.

## Main finding
This is an every-minute VWAP reversal model. It is different from Noise Area
and from the previous five-minute Test C. A high percentage total return in
the paper does not imply a high trade win rate, a low reward/risk payoff, or
that a one-contract NQ version will reproduce the reported ETF equity curve.

## Paper rules and implementation decisions
Source: Zarattini and Aziz, "Volume Weighted Average Price (VWAP): The Holy
Grail for Day Trading Systems", November 13, 2023, SSRN 4631351.

1. Data: completed one-minute OHLCV bars, US cash session 09:30..16:00 ET.
2. Reset VWAP daily; exclude premarket and after-hours bars. Use cumulative
   HLC3 times volume divided by cumulative volume (PDF pp2-3).
3. At 09:31, after the first complete minute, close above VWAP means long,
   close below means short. Repeat at every completed minute (pp8-11).
4. If already on the correct side, hold. If the close switches sides, reverse
   at the next bar's open; the reversal exits one position and opens another.
5. An intrabar wick through VWAP does not trigger a trade. No fixed price
   stop or take profit. No entry cap. No overnight exposure on complete days.
6. End-of-session exposure is liquidated at the final bar close in the
   HISTORICAL backtest convention. See the execution limitation below.

The short-entry sentence on p8 refers to the first candle "opens below" VWAP,
whereas the surrounding rules/examples use completed candles. This source
ambiguity is resolved by using CLOSE symmetrically for both directions.
Exact equality with VWAP: hold the existing side, or stay flat if flat. The
paper does not specify equality. There is no tick buffer or crossing filter.

NQ quantity is TradeSize=1 by default. The paper puts all available ETF equity
into each trade and compounds. Fixed-contract NQ is a deliberate sizing change;
do not describe its percentage returns as a replication of the QQQ portfolio.
EnableLongs/EnableShorts default True. Turning either off is a separate test:
an opposite signal exits the held side even if the new direction is disabled.

## Installation
1. Create a NEW SIGNAL: NQ_VWAP_Trend_v1_BT. Paste the whole Signal.txt file
   and compile. This is source text, not an importable compiled PLA archive.
2. Create a NEW INDICATOR: NQ_VWAP_Trend_v1. Paste Indicator.txt and compile.
3. Apply to your NQ symbol on a ONE-MINUTE chart. Chart clock: verified
   Eastern/New York including DST, not a fixed UTC offset all year.
4. Set intrabar order generation OFF and indicator every-tick updating OFF.
   Disable pyramiding; run this signal alone for the baseline comparison.
5. Match shared inputs, MaxBarsBack and data range between the two studies.
   Only Date[1] is referenced. No 14-day warm-up is needed for this model;
   calculation must begin before a session's first minute for that day to trade.
6. Apply the indicator to the PRICE pane using the same price scale. It
   displays VWAP; trade arrows come from the signal. Turn off plot connections
   across missing values if the platform offers that setting. NoPlot does not
   by itself guarantee separate session segments with every plot style.
7. Supply actual broker/exchange fees and slippage in the strategy properties.
   The code does not subtract costs manually, avoiding double-counting.
8. Verify a long-to-short reversal ends SHORT TradeSize contracts, and a
   short-to-long reversal ends LONG TradeSize contracts. A one-contract
   reversal transacts two contracts, so costs apply to both legs.

## Timestamp inputs and closing execution
RTHOpenTime=0930, RTHCloseTime=1600. BarTimeIsEnd=True by default, matching the
earlier reported END-labeled data, but verify the actual NQ CHART after import.

End labels: 09:30 is pre-RTH. First included bar is 09:31 (09:30..09:31).
Last included bar is 16:00 (15:59..16:00).
Start labels: set BarTimeIsEnd=False. First included bar is 09:30; last is
15:59. The code converts the label to an interval-end minute before filtering.
Do not set the flag based solely on the raw CSV if the importer shifted times.

Signal is computed after the minute closes; Next Bar At Market uses the next
available bar open. For contiguous bars that OPEN is at the previous bar's
end clock. This is not an additional one-full-minute delay. Actual transmission
latency and adverse execution prices must be tested separately.

At the last RTH bar the code gives the closing exit priority and emits no new
entry/reversal. The exit is This Bar On Close: a HISTORICAL fill at that bar's
close, chosen to represent the paper's end-of-day price and avoid the old
15:59-next-bar-open timing mismatch. It is not a promise of a live fill at the
closing print. Keep automated trading OFF for this baseline. A live scheduled
exit and a next-executable-price closing sensitivity test are separate work.
Review how your platform applies slippage to these closing orders as well.

## Data-quality behaviour
Missing opening minute, a subsequent missing/duplicate minute, negative volume
or invalid OHLC disables further VWAP signals for that day. If exposed, a
next-bar liquidation is requested, unless on the last RTH bar where the
historical close exit has priority. Recovery outside RTH also requests a
next-bar exit if exposure leaked. Such trades are data-failure diagnostics,
not part of a clean research sample.

Zero-volume bars contribute zero weight; no signal is possible before positive
cumulative volume. No Close-as-VWAP fallback. When volume is zero all session,
the final bar prints a warning. Ensure Volume is actual traded volume in the
imported futures data. A tick-count substitution is not the source formula.

Filter missing/shortened sessions before the primary comparison and retain a
separate exclusion list. Online checks detect gaps only when the next bar
arrives and cannot foresee an absent future bar or calendar early close.
A missing final RTH bar cannot be repaired into a true 16:00 fill. The code
does not include a holiday calendar; do not claim every early close is handled.
Use coherent contract prices and audit rolls. NQ VWAP and QQQ VWAP will differ
because their traded prices and volume are different even though both relate
to the Nasdaq-100.

## What the paper reports (not our NQ results)
Period January 2, 2018 to September 28, 2023; initial ETF equity $25,000.

| Metric | QQQ VWAP | TQQQ VWAP |
|---|---:|---:|
| Ending capital | $192,656 | $2,085,417 |
| Total return | 671% | 8,242% |
| Maximum drawdown | 9.4% | 36.1% |
| Sharpe (authors' reported definition) | 2.1 | 1.7 |
| Trades | 21,967 | 22,399 |
| Trade hit rate | 17.0% | 17.2% |
| Average gain / average loss | 5.67 | 5.48 |
| Worst daily return | -5.1% | -22.7% |

PDF pp14-18, Tables 1-4. Returns, leverage and compounding differ across the
ETF portfolios. This is not a high-win-rate system: frequent small losses are
offset by comparatively large winners in the authors' sample.

Costs: assumed ZERO slippage and $0.0005 per share commission (pp9-10). These
are historical author assumptions, not a statement of current broker fees.
Footnote 6 explicitly says higher commissions can affect effectiveness.
Do not transfer that commission number to futures contracts.

Source consistency: the abstract rounds QQQ buy/hold drawdown to 37%, while
Tables 1/2 give 35.6%. Table 3 reports TQQQ commission $400,619 while nearby
prose gives $400,616. Reported Sharpe uses an author-described return/volatility
definition; do not silently treat it as independently recomputed excess-return
Sharpe. We use table values where there is a discrepancy.

The time-of-day section (pp21-22) finds more gross one-share P&L in the morning
and final hour and suggests avoiding noon..15:00 as a possible cost-efficiency
change. It is not a demonstrated replacement full-system backtest. The baseline
here trades the full cash session; no noon filter or personal no-news overlay.

## NQ costs and first comparison
CME NQ outright specification: $20 per index point; 0.25 point tick = $5.
One tick adverse slippage on entry AND exit is $10 per one-contract round
trip before commissions. Example only: $5 round-trip fees plus that slippage
is $15 per completed one-contract round trip. Use your actual fee schedule;
stress 0/1/2 ticks per side while keeping all rules fixed. Zero is a diagnostic.
NQ notional is price times $20 per contract; fixed one NQ is not equivalent
to investing exactly 100% of a $25,000 ETF account, nor to automatic 3x TQQQ.

First compare overlapping 2018-01-02..2023-09-28 if NQ coverage permits, then
report later periods separately. This is a transfer test, not a pristine
out-of-sample proof. Use original price/volume and traceable roll conventions.
Export the full trades, daily equity and settings with commissions/slippage.
Report win rate, payoff ratio, average NET trade, PF, max strategy drawdown,
largest loss, trades per day and concentration in the largest winners. Keep
zero-trade days. A prop pass rate needs intraday equity and the firm's exact
drawdown/consistency mechanics; no pass rate or profit forecast is supplied.

## Verification here and limits
Python reference checks cover session membership for both label conventions,
equivalent VWAP paths, first-minute direction, multiple reversals, equality,
direction switches, last-bar exit priority, zero volume, daily reset and gaps.
Source checks cover matching calculation cores and basic syntax structure.
No MultiCharts compiler or execution engine was available: compile locally and
compare signal times and fills before interpreting any performance numbers.

## Sources
Primary research: uploaded ssrn-4631351.pdf, 26 pages; definitions pp2-3,
strategy pp8-11, sizing/costs pp9-10, results pp14-18, time of day pp21-22.
CME current product overview:
https://www.cmegroup.com/markets/equities/nasdaq/e-mini-nasdaq-100.html
CME contract multiplier/tick reference (historical fact card, ONLY these units used):
https://www.cmegroup.com/trading/equity-index/files/emini-nasdaq-100-futures-options.pdf
Compatible-language order/reversal and historical closing-order documentation
(TradeStation documentation is not a MultiCharts compile test):
https://help.tradestation.com/10_00/eng/tsdevhelp/elword/word/sellshort_reserved_word_.htm
