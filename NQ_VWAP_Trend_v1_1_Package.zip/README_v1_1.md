# NQ VWAP Trend v1.1 - volume and bar-label correction

This fixes an implementation issue in v1; it is not an optimization.

## What the screenshot establishes
- The diagnostic inputs were RTH=0931..1601 and END labels. These were the
  supplied settings, not a verified statement about the source data.
- Last calculation was at 20:00. Outside RTH at that time is expected.
- The field used as volume and cumulative session volume were zero.
- A prior failed day was recorded at Date=1200318 (2020-03-18), with 13:12
  received when 12:59 was expected. That historical gap is not evidence that
  the latest September 2026 session has the same gap.

The user clarified that the CSV minute beginning 09:30 appears as 09:31 on
the chart. Thus the CHART uses END labels: 09:31 means 09:30..09:31.
Use BarTimeIsEnd=True. The session inputs are the actual clock boundaries
09:30..16:00, NOT the first/last bar labels shifted by another minute.
The earlier tentative start-label interpretation is superseded.

## Confirmed code issue and correction
MultiCharts documentation states that Volume on intraday charts represents
the uptick component. Ticks supplies total contracts when chart volume is
configured for Trade Volume, or number of trades when configured for Tick Count.
v1 used Volume; v1.1 explicitly assigns BarVolume=Ticks and weights HLC3 by it.
This can explain the empty VWAP when total historical volume exists but the
uptick field is absent/zero. We have not remotely verified the user's chart
volume setting, Ticks readings or CSV volume contents. No fake fallback is used.

## Install and exact inputs
1. Create new studies from the .txt sources:
   SIGNAL NQ_VWAP_Trend_v1_1_BT
   INDICATOR NQ_VWAP_Trend_v1_1
   optional INDICATOR NQ_VWAP_Diagnostic_v1_1
2. Compile. Remove the older versions from the chart before applying the new
   studies. Keep the original code saved for a controlled comparison.
3. NQ one-minute chart, verified Eastern clock. Configure the chart's volume
   basis as TRADE VOLUME, not Tick Count. Verify total volume against an
   actual CSV minute; nonzero Ticks alone does not prove its units are contracts.
4. In EVERY applied study set these explicitly (saved templates may retain
   old values): RTHOpenTime=0930, RTHCloseTime=1600, BarTimeIsEnd=True.
   TradeSize=1, EnableLongs=True, EnableShorts=True in the signal.
5. Intrabar order generation OFF; indicator every-tick updating OFF. Same
   loaded history and MaxBarsBack, and the same price pane/scale for plots.
6. Inspect a full daytime session. With END labels the bars 09:31..16:00
   are included. The first decision occurs when chart bar 09:31 closes.
7. If still blank, add the v1.1 diagnostic and send its full status text.
   It displays both raw Volume and Ticks, selected cumulative volume, timing
   and the first specific data failure. ShowStatus defaults True.

## Trading rules retained
Every completed one-minute close above RTH VWAP targets long; below targets
short. Same side holds; opposite side reverses next bar at market. Equality
holds. One fixed contract default; unlimited sequential reversals, no pyramiding,
fixed target, hard stop or daily entry cap. Costs belong in MultiCharts settings.
The same total-volume calculation is used in all three sources.

Historical end-of-day exit remains This Bar On Close at the final RTH bar
(16:00 end label means interval 15:59..16:00). This is not live closing-price
execution. Auto-trading stays OFF for this research baseline.

## Data checks retained
Missing first bar, later gap/duplicate or invalid OHLCV still disables further
signals that session. Changing volume source does not repair missing minutes.
Zero volume is not replaced by Close or a constant. Missing/shortened sessions
need exclusion from the primary sample; no calendar is embedded. Do not disable
these checks merely to force a favorable result or conceal missing observations.

## Validation status
Checked start/end interval membership, 390 RTH bars for end labels, weighted
VWAP with zero uptick but positive total volume, accessor use in all sources,
unchanged signal order logic and static block/parenthesis structure.
No MultiCharts compilation, remote chart access or NQ backtest was available.
Correct plot visibility and platform fills still need local verification.

## Primary technical sources
https://www.multicharts.cn/powerlanguage/03_words/Data_Information_General/Volume.htm
https://www.multicharts.cn/powerlanguage/03_words/Data_Information_General/Ticks.htm
Paper: uploaded ssrn-4631351.pdf, HLC3 VWAP pp2-3 and trading rules pp8-11.
